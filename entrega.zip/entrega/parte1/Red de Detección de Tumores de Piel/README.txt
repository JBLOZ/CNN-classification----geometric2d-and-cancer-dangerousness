Para ejecutar el programa ejecutar skinCancerResNet50TransferLearning('train') para entrenar y skinCancerResNet50TransferLearning('test') para testearlo

Addons necesarios:

Deep Learning Toolbox
Image Processing Toolbox
Parallel Computing Toolbox
Deep Learning Toolbox Model for ResNet-50 Network