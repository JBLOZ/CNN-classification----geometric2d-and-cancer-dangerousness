Para ejecutar el programa ejecutar shapesDataClassifierIntegrated.m, si se desea entrenar el modelo cambiar el nombre de trained2Dgeometricshapes.mat o borrarlo

Addons necesarios:

Deep Learning Toolbox
Image Processing Toolbox
Parallel Computing Toolbox