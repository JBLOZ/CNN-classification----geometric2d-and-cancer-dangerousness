Para ejecutar el programa ejecutar preentrenada.m, si se quiere cambiar de imagen cambiar la variable nombre_img a cualquiera de las siguientes (coches.jpg, leon.png, llama.jpg, nevera.jpg, paraguas.jpg, pimientos.jpg)
Addons necesarios:

Deep Learning Toolbox
Image Processing Toolbox
Deep Learning Toolbox Model for GoogLeNet Network